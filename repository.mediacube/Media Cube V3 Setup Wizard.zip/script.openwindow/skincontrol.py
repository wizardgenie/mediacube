import xbmcplugin, xbmcgui, xbmc, xbmcaddon

xbmc.executebuiltin('StopScript(special://home/addons/script.openwindow/launch.py)')
xbmc.executebuiltin('RunScript(special://home/addons/script.openwindow/launch.py)')